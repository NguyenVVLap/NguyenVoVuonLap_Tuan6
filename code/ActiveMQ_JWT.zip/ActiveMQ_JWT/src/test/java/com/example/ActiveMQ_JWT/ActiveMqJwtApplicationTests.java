package com.example.ActiveMQ_JWT;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ActiveMqJwtApplicationTests {

	@Test
	void contextLoads() {
	}

}
